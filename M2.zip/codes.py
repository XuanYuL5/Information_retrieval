import os
import numpy as np
import math
import json
# import nltk
# nltk.download('punkt')
from tqdm import tqdm
from glob import glob
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize
import pandas as pd
import scipy.io as scio
import time


class Posting:
    """
    Represents the Posting of a term in a given document, along with the frequency of appearances in the same one.
    """
    def __init__(self, docId, frequency, norm_tf=0, tfidf=0):
        self.docId = docId
        self.frequency = frequency
        self.norm_tf = norm_tf
        self.tfidf = tfidf
        
    def __repr__(self):
        """
        String representation of the Posting object
        """
        return str(self.__dict__)

class PostingEncoder(json.JSONEncoder):
    '''
    Posting Encoder function.
    '''
    def default(self, obj):
        if isinstance(obj, Posting):
            return eval(str(obj))
        else:
            return super(PostingEncoder, self).default(obj)

class InvertedIndex:
    """
    Inverted Index class.
    """
    def __init__(self):
        self.index = dict()
        self.ps = PorterStemmer()
        self.index_file_num = 0
        '''
        Use a dictionary to store the memory
        '''
        self.indexes_memory = dict()
        if os.path.exists('indexes/memory.json'):
            with open('indexes/memory.json', 'r') as f:
                self.indexes_memory = json.load(f)


    def __repr__(self):
        """
        String representation of the Database object
        """
        return str(self.index)
        
    # Codes from: https://medium.com/@fro_g/writing-a-simple-inverted-index-in-python-3c8bcb52169a#:~:text=What%20is%20an%20Inverted%20Index,the%20term%20in%20the%20document.
    def index_document(self, document):
        """
        Process a given document, save it to the DB and update the index.
        """
        
        # Remove punctuation from the text.
        terms = []
        punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '&', '!', '*', '@', '#', '$', '%', '<', '>','--','=','/','|','’','‘','{','}','`','\\','\'','-','_','+','\\\\','\\\\\\','~']

        for p in punctuations:
            document['content'] = document['content'].replace(p, ' ')

        words = word_tokenize(document['content'])
        for w in words:
            if w.isdigit():
                continue
            terms.append(self.ps.stem(w))
        postings_dict = dict()
        last_tag = None
        important_tags = ['b', 'strong', 'h1', 'h2', 'h3', 'title']

        # Dictionary with each term and the frequency it appears in the text.
        for term in terms:
            term_frequency = postings_dict[term].frequency if term in postings_dict else 0
            if last_tag is None and term in important_tags:
                last_tag = term
                postings_dict[term] = Posting(document['url'], term_frequency + 1)
            elif last_tag is None and term not in important_tags:
               postings_dict[term] = Posting(document['url'], term_frequency + 1)
            elif last_tag is not None and term == last_tag:
                postings_dict[term] = Posting(document['url'], term_frequency + 1)
                last_tag = None
            else:
                postings_dict[term] = Posting(document['url'], term_frequency + 10)
        
        
        for term, posting in postings_dict.items():
            posting.norm_tf = posting.frequency / len(terms)

        # Update the inverted index
        update_dict = { key: [posting]
                       if key not in self.index
                       else self.index[key] + [posting]
                       for (key, posting) in postings_dict.items() }
        self.index.update(update_dict)
    
    def construct_index(self, documents_path):
        """
        Construct the inverted index.
        """
        count = 0
        for document_path in tqdm(documents_path):
            count += 1
            with open(document_path, 'r') as f:
                document = json.load(f)
                self.index_document(document)
                if len(self.index) > 5000:
                    self.save_index_file(self.index, f'index_files/{self.index_file_num}.json')
                    self.index_file_num += 1
                    self.index = dict()
        self.save_index_file(self.index, f'index_files/{self.index_file_num}.json')
        self.index_file_num += 1
        self.index = dict()

    def save_index_file(self, index, file_name):
        """
        Save the index to a file.
        """
        json_str = json.dumps(index, indent=4, cls=PostingEncoder)
        with open(file_name, 'w') as f:
            f.write(json_str)
    
    def merge_index_files(self):
        """
        Merge all the index files into indexed files.
        """
        indexes = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        unique_token_count = 0
        for index in tqdm(indexes):
            index_merged = dict()
            for i in range(self.index_file_num):
                with open(f'index_files/{i}.json', 'r') as f:
                    data = json.load(f)
                    for key, value in data.items():
                        if key[0] == index:
                            if key not in index_merged:
                                index_merged[key] = value
                            else:
                                index_merged[key] += value
            unique_token_count += len(index_merged)
            self.save_index_file(index_merged, f'index_files/{index}.json')
        
        for i in range(self.index_file_num):
            with open(f'index_files/{i}.json', 'r') as f:
                data = json.load(f)
                for key, value in data.items():
                    if key[0] not in indexes:
                        if key not in index_merged:
                            index_merged[key] = value
                        else:
                            index_merged[key] += value
        unique_token_count += len(index_merged)
        self.save_index_file(index_merged, 'index_files/others.json')
        index_merged = dict()
        print('Number of Unique Tokens:', unique_token_count)

    
    
    def compute_tf_idf(self):
        """
        Compute the tf-idf for all the terms in the index.
        """
        indexes = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'others']
        for index in tqdm(indexes):
            with open(f'index_files/{index}.json', 'r') as f:
                data = json.load(f)
                for key, value in data.items():
                    for posting in value:
                        posting['tf_idf'] = posting['norm_tf'] * math.log10(55393 / len(value))
            self.save_index_file(data, f'index_files/{index}.json')

    
    def split_files(self):
        indexes = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        index_memory = dict()
        for index in tqdm(indexes):
            index_split = dict()
            index_json = dict()
            index_2_json = dict()
            with open(f'index_files/{index}.json', 'r') as f:
                data = json.load(f)
                for key, value in data.items():
                    # if key is a single character, just save it to the file
                    if len(value) > 10000:
                        index_memory[key] = value
                    elif len(key) == 1:
                        index_json[key] = value
                        self.save_index_file(index_json, f'indexes/{index}.json')
                    elif len(key) == 2:
                        try:
                            if key == 'is':
                                print(key)
                            index_2_json[key] = value
                            self.save_index_file(index_2_json, f'indexes/{key}.json')
                            index_2_json = dict()
                        except:
                            print(key)
                            continue
                    elif key[1] in indexes and key[2] in indexes:
                        if key[1] not in index_split:
                            index_split[key[1]] = dict()
                        if key[2] not in index_split[key[1]]:
                            index_split[key[1]][key[2]] = dict()
                        index_split[key[1]][key[2]][key] = value
                    else:
                        if 'others' not in index_split:
                            index_split['others'] = dict()
                        index_split['others'][key] = value

            for key, value in index_split.items():
                if key == 'others':
                    self.save_index_file(value, f'indexes/{index}{key}.json')
                else:
                    for key2, value2 in value.items():
                        self.save_index_file(value2, f'indexes/{index}{key}{key2}.json')
        self.save_index_file(index_memory, 'indexes/memory.json')

    def get_postings(self, term):
        """
        Read the term from the index and return the posting list.
        """
        indexes = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        if term in self.indexes_memory:
            return self.indexes_memory[term]
        elif term[0] not in indexes:
            filename = 'indexes/others.json'
        elif len(term) == 1 and term in indexes:
            filename = f'indexes/{term}.json'
        elif len(term) == 2:
            filename = f'indexes/{term}.json'
        elif term[1] in indexes and term[2] in indexes:
            filename = f'indexes/{term[0]}{term[1]}{term[2]}.json'
        else:
            filename = f'indexes/{term}others.json'
        try:
            with open(filename, 'r') as f:
                data = json.load(f)
                return data[term]
        except:
            return None

os.makedirs('index_files', exist_ok=True)
os.makedirs('indexes', exist_ok=True)
index = InvertedIndex()

files_path = glob('DEV/*/*.json')
print(len(files_path))
index.construct_index(files_path)
index.merge_index_files()
index.compute_tf_idf()
index.split_files()

def get_cos_similar_multi(v1, v2):
    num = np.dot([v1], np.array(v2))
    denom = np.linalg.norm(v1) * np.linalg.norm(v2, axis=0)
    res = num / denom
    res[np.isneginf(res)] = 0
    return 0.5 + 0.5 * res

def lookup_query(index, query):
    terms = []
    punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '&', '!', '*', '@', '#', '$', '%', '<', '>','--','=','/','|','’','‘','{','}','`','\\','\'','-','_','+','\\\\','\\\\\\','~']

    for p in punctuations:
        query = query.replace(p, ' ')

    words = word_tokenize(query)
    for w in words:
        if w.isdigit():
            continue
        terms.append(index.ps.stem(w))

    docId_set = set()
    postings_dict = dict()
    for term in terms:
        postings = index.get_postings(term)
        postings_dict[term] = postings
        if postings is not None:
            for posting in postings:
                docId_set.add(posting['docId'])
    docId_to_i = dict()
    term_to_i = dict()
    i_to_docId = dict()
    for i, term in enumerate(terms):
        term_to_i[term] = i
    if len(docId_set) == 0:
        return None
    else:
        for i, docId in enumerate(docId_set):
            docId_to_i[docId] = i
            i_to_docId[i] = docId
        term_docs_matrix = np.zeros((len(terms), len(docId_set)))
        for term, postings in postings_dict.items():
            for posting in postings:
                term_docs_matrix[term_to_i[term], docId_to_i[posting['docId']]] = posting['tf_idf']
    # calculate cosine sim
    cos_mat = get_cos_similar_multi(np.ones_like(range(len(terms))), term_docs_matrix)
    inds = np.argsort(cos_mat[0])[-1:-6:-1]
    for ind in inds:
        print(i_to_docId[ind])

x = input('Enter your QUERY, input Q to exit\n')
while x != 'Q':
    start = time.time()
    lookup_query(index, x)
    print('This query uses ', time.time() - start, 'seconds')
    x = input('\nEnter your QUERY, input Q to exit\n')
