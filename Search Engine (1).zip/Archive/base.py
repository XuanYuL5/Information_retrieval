class Document:
    """Represents a document in the corpus."""
    def __init__(self, file_path, url, docId, auth = 1.0, hub = 1.0, pagerank = 1.0):
        self.file_path = file_path
        self.url = url
        self.docId = docId
        self.auth = auth
        self.hub = hub
        self.pagerank = pagerank
        self.parents = []
        self.children = []

    
    def __repr__(self):
        return str(self.__dict__)

    def update_auth(self, docId_to_doc):
        self.auth = sum(docId_to_doc[node].hub for node in self.parents)

    def update_hub(self, docId_to_doc):
        self.hub = sum(docId_to_doc[node].auth for node in self.children)

class Graph:
    """A graph for HITS and PageRank algorithm."""
    def __init__(self):
        self.nodes = []

    def normalize_auth_hub(self):
        auth_sum = sum(node.auth for node in self.nodes)
        hub_sum = sum(node.hub for node in self.nodes)

        for node in self.nodes:
            node.auth /= auth_sum
            node.hub /= hub_sum

    def normalize_pagerank(self):
        pagerank_sum = sum(node.pagerank for node in self.nodes)

        for node in self.nodes:
            node.pagerank /= pagerank_sum

class Posting:
    """Represents the Posting of a term in a given document."""
    def __init__(self, docId, term_count = 0):
        self.docId = docId
        self.term_count = term_count
        self.positions = []
        self.term_frequency = 0
        self.tf_idf = 0
    
    def __repr__(self):
        return str(self.__dict__)