from django.shortcuts import render
from search import Search
import time
import nltk
nltk.download('punkt')

search = Search()

def query(request):
    return render(request, 'engine/home.html')
    
def results(request):
    if request.method == "POST":
        query = request.POST.get('search')
        if query == "":
            return render(request, 'engine/home.html')
        else:
            start = time.time()
            if request.POST.get('boolean'):
                results = search.boolean_retrieval(query)
            else:
                results = search.free_text_search(query)
            end = time.time() - start

            context = {
                'results':results,
                'end': round(end * 1000,2)
            }
            return render(request, 'engine/results.html', context)
    else:
        return render(request, 'engine/results.html')


def about(request):
    return render(request, 'engine/about.html')