import os
import math
import json
import hashlib
import numpy as np
from tqdm import tqdm
from glob import glob
from bs4 import BeautifulSoup
from nltk.stem import PorterStemmer
from multiprocessing import Process
from nltk.tokenize import word_tokenize
from base import Document, Graph, Posting

# import nltk
# nltk.download('punkt')

class Indexer:
    """An Indexer for the corpus."""
    def __init__(self, documents_path):
        self.documents_path = documents_path
        self.documents = glob(documents_path) # all documents path
        self.duplicates = {} # duplicated url as key, url as value
        self.url_to_doc = {} # url as key, document as value
        self.docId_to_doc = {} # docId as key, document as value
        self.graph = Graph()
        self.inverted_index = {} # term as key, posting list as value
        self.indexes = 'abcdefghijklmnopqrstuvwxyz'

    def remove_duplicates(self):
        """Detect and eliminate duplicate pages"""

        if os.path.exists('results/duplicates.npz'):
            self.duplicates = np.load('results/duplicates.npz', allow_pickle=True)['arr_0'][()]
            return

        print('Calculating md5...')
        url_to_md5 = {}
        url_to_path = {}
        for document in tqdm(self.documents):
            data = json.load(open(document, 'r'))
            doc_md5 = hashlib.md5(data['content'].encode('utf-8'))
            url_to_md5[data['url']] = doc_md5.hexdigest()
            url_to_path[data['url']] = document

        print('Detecting duplicates...')
        duplicates = []
        for url, md5 in tqdm(url_to_md5.items()):
            if url in duplicates:
                continue
            for url2, md5_2 in url_to_md5.items():
                # if the md5 values are the same, the strings are the same
                if url != url2 and md5 == md5_2:
                    self.duplicates[url2] = url
                    duplicates.append(url2)
        print('There are {} duplicates'.format(len(duplicates)))

        print('Removing duplicates...')
        for url in tqdm(duplicates):
            path = url_to_path[url]
            os.system('rm ' + path)

        self.documents = glob(self.documents_path) # update documents path
        print("There are {} documents remaining".format(len(self.documents)))
        np.savez('results/duplicates.npz', self.duplicates)
    
    def load_documents(self):
        """Load all documents' url and docId into memory."""

        if self.docId_to_doc == {} and self.url_to_doc == {}:
            if os.path.exists('results/documents_scored.npz'):
                documents = np.load('results/documents_scored.npz', allow_pickle=True)['arr_0'][()]
                for document in documents:
                    self.docId_to_doc[document.docId] = document
                    self.url_to_doc[document.url] = document
            elif os.path.exists('results/documents.npz'):
                documents = np.load('results/documents.npz', allow_pickle=True)['arr_0'][()]
                for document in documents:
                    self.docId_to_doc[document.docId] = document
                    self.url_to_doc[document.url] = document
            else:
                print('Loading documents...')
                i = 0
                for document in tqdm(self.documents):
                    with open(document, 'r') as f:
                        data = json.load(f)
                        self.docId_to_doc[i] = Document(document, data['url'], i)
                        self.url_to_doc[data['url']] = self.docId_to_doc[i]
                        i += 1
                np.savez('results/documents.npz', list(self.docId_to_doc.values()))

    def build_graph(self):
        """Build a graph for HITS and PageRank algorithm."""

        self.remove_duplicates()
        self.load_documents()
        if os.path.exists('results/duplicates.npz') and self.duplicates == {}:
            self.duplicates = np.load('results/duplicates.npz', allow_pickle=True)['arr_0'][()]

        print('Building graph...')
        for document in tqdm(self.documents):
            with open(document, 'r') as f:
                document = json.load(f)
                url = document['url']
                html = document['content']
                docId = self.url_to_doc[url].docId
                soup = BeautifulSoup(html, 'html.parser')
                a_tags = soup.find_all('a', href = True)

                if len(a_tags) > 0:
                    for a in a_tags:
                        href = a['href']
                        if href in self.duplicates:
                            href = self.duplicates[href]
                        if href in self.url_to_doc:
                            href_docId = self.url_to_doc[href].docId
                            if docId not in self.url_to_doc[href].parents:
                                self.url_to_doc[href].parents.append(docId)
                            if href_docId not in self.url_to_doc[url].children:
                                self.url_to_doc[url].children.append(href_docId)

        self.graph.nodes = list(self.url_to_doc.values())
        np.savez('results/graph.npz', self.graph)

    def hits_pagerank(self):
        """HITS algorithm and PageRank algorithm."""
        if os.path.exists('results/graph.npz') and self.graph.nodes == []:
            self.graph = np.load('results/graph.npz', allow_pickle=True)['arr_0'][()]
        elif self.graph.nodes == []:
            self.build_graph()
        self.load_documents()

        print('Running HITS...')
        for i in tqdm(range(100)):
            for node in self.graph.nodes:
                node.update_auth(self.docId_to_doc)
            for node in self.graph.nodes:
                node.update_hub(self.docId_to_doc)
            self.graph.normalize_auth_hub()

        print('Running PageRank...')
        for i in tqdm(range(100)):
            for node in self.graph.nodes:
                node.pagerank = sum(self.docId_to_doc[parent].pagerank for parent in node.parents)
            self.graph.normalize_pagerank()

        np.savez('results/documents_scored.npz', self.graph.nodes)
    
    def index_document(self, document):
        ps = PorterStemmer()
        postings_dict = dict()
        self.load_documents()

        html = document['content']
        url = document['url']
        docId = self.url_to_doc[url].docId
        soup = BeautifulSoup(html, 'html.parser')
        important_tags = ['b', 'strong', 'h1', 'h2', 'h3', 'title']
        for tag in important_tags:
            tags = soup.find_all(tag)
            if len(tags) > 0:
                for t in tags:
                    tokens = word_tokenize(t.text)
                    for token in tokens:
                        if token.isalnum():
                            term = ps.stem(token.lower())
                            term_count = postings_dict[term].term_count if term in postings_dict else 0
                            postings_dict[term] = Posting(docId, term_count + 10)

        tokens = word_tokenize(document['content'])
        postion = 0
        for token in tokens:
            if token.isalnum():
                term = ps.stem(token.lower())
                term_count = postings_dict[term].term_count if term in postings_dict else 0
                postings_dict[term] = Posting(docId, term_count + 1)
                postings_dict[term].positions.append(postion)
                postion += 1
        
        for term, posting in postings_dict.items():
            posting.term_frequency = posting.term_count / postion

        # Update the inverted index
        update_dict = { key: [posting]
                       if key not in self.inverted_index
                       else self.inverted_index[key] + [posting]
                       for (key, posting) in postings_dict.items() }
        self.inverted_index.update(update_dict)
        
    def construct_inveted_index(self, documents, group_id):
        """Construct the inverted index."""
        group_id *= 10000
        for document in tqdm(documents):
            with open(document, 'r') as f:
                document = json.load(f)
                self.index_document(document)
                if len(self.inverted_index) > 5000:
                    np.savez(f'temp_files/{group_id}.npz', self.inverted_index)
                    self.inverted_index = {}
                    group_id += 1
        np.savez(f'temp_files/{group_id}.npz', self.inverted_index)
        self.inverted_index = {}
    
    def multiple_processes_for_index_construction(self, processes_num):
        """Use multiple processes to construct the inverted index."""

        documents_group = [self.documents[i::processes_num] for i in range(processes_num)]
        p = []
        for i in range(processes_num):
            p.append(Process(target=self.construct_inveted_index, args=(documents_group[i], i)))
            p[i].start()
        for i in range(processes_num):
            p[i].join()

    def merge_temp_files(self):
        """Merge all the temp index files into indexed files."""

        print('Merging temp files...')
        terms = []
        temp_files = glob('temp_files/*.npz')
        index_memory = {}
        index_others = {}
        group_num = 2

        for i in range(group_num):
            indexes = self.indexes[i::group_num]
            print('Constructing index: ', indexes, '...')
            index_merged = {}
            index_index = {}
            for index in indexes:
                index_merged[index] = {}
                index_index[index] = {}
            for file in tqdm(temp_files):
                data = np.load(file, allow_pickle=True)['arr_0'][()]
                for key, value in data.items():
                    if key[0] in indexes:
                        if key not in index_merged[key[0]]:
                            index_merged[key[0]][key] = value
                        else:
                            index_merged[key[0]][key] += value
                    if key[0] not in self.indexes:
                        if key not in index_others:
                            index_others[key] = value
                        else:
                            index_others[key] += value
            for index, value in index_merged.items():
                for key, value2 in value.items():
                    if len(value) > 20000 or len(key) == 1 or len(key) == 2:
                        index_memory[key] = value2
                    else:
                        index_index[index][key] = value2
            for index, value in index_index.items():
                self.compute_tf_idf(value, terms)
                np.savez(f'coarse_index_files/{index}.npz', value)

        print('Saving index files...')
        self.compute_tf_idf(index_memory, terms)
        self.compute_tf_idf(index_others, terms)
        np.savez(f'index_files/memory.npz', index_memory)
        np.savez(f'index_files/others.npz', index_others)
        np.savez(f'results/terms.npz', terms)

    def compute_tf_idf(self, inverted_index, terms):
        """Compute the tf-idf for all the terms in the index."""
        for term, posting_list in inverted_index.items():
            for posting in posting_list:
                idf = math.log10(len(self.documents) / len(posting_list))
                posting.tf_idf = posting.term_frequency * idf
            terms.append(term)

    def construct_n_grams_indexing(self):
        """Create a dictionary of n-grams to words mapping."""
        vocab = np.load('results/terms.npz', allow_pickle=True)['arr_0'][()]
        n = [2, 3]
        for k in n:
            print(f'Constructing {k}-gram indexing...')
            k_gram_indexes = {}
            for term in tqdm(vocab):
                for i in range(len(term) - k + 1):
                    k_gram = term[i:i+k]
                    if k_gram not in k_gram_indexes:
                        k_gram_indexes[k_gram] = []
                    k_gram_indexes[k_gram].append(term)
            np.savez(f'results/{k}_gram_indexes.npz', k_gram_indexes)
    
    def coarse_to_fine(self):
        """Coarse to fine indexing."""
        print('Coarse to fine indexing...')
        for index in tqdm(self.indexes):
            for file in glob(f'coarse_index_files/{index}.npz'):
                data = np.load(file, allow_pickle=True)['arr_0'][()]
                inverted_index = {}
                for key, value in data.items():
                    if key[1] in self.indexes and key[2] in self.indexes:
                        if key[1] not in inverted_index:
                            inverted_index[key[1]] = {}
                        if key[2] not in inverted_index[key[1]]:
                            inverted_index[key[1]][key[2]] = {}
                        inverted_index[key[1]][key[2]][key] = value
                    else:
                        if 'others' not in inverted_index:
                            inverted_index['others'] = dict()
                        inverted_index['others'][key] = value

                for key, value in inverted_index.items():
                    if key == 'others':
                        np.savez(f'index_files/{index}-others.npz', value)
                    else:
                        for key2, value2 in value.items():
                            np.savez(f'index_files/{index}{key}{key2}.npz', value2)