import os
import warnings
from indexer import Indexer
from search import Search
warnings.filterwarnings('ignore')

if __name__ == '__main__':

    os.makedirs('temp_files', exist_ok=True)
    os.makedirs('index_files', exist_ok=True)
    os.makedirs('coarse_index_files', exist_ok=True)
    os.makedirs('results', exist_ok=True)
    # documents_path = 'data/ANALYST/*/*.json' # for test
    documents_path = 'data/DEV/*/*.json'

    indexer = Indexer(documents_path)
    indexer.hits_pagerank()
    indexer.multiple_processes_for_index_construction(6)
    indexer.merge_temp_files()
    indexer.construct_n_grams_indexing()
    indexer.coarse_to_fine()

    search = Search()
    search.free_text_search('ACM')
    search.free_text_search('cristina lopes')
    search.free_text_search('Machine Learning')
    search.free_text_search('master of software engineering')