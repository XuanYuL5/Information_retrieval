import json
import math
import os
import numpy as np
from bs4 import BeautifulSoup
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize
from base import Document, Posting
from numpy.linalg import norm

class Search:
    def __init__(self):
        if os.path.exists('index_files/memory.npz'):
            self.inverted_indexes = np.load('index_files/memory.npz', allow_pickle=True)['arr_0'][()]
            print('Inverted Index Loaded.')
        else:
            print('Inverted Index Not Found')
        self.indexes = 'abcdefghijklmnopqrstuvwxyz'
        self.docId_to_doc = {}
        self.load_documents()

    def load_documents(self):
        """Load all documents' url and docId into memory."""

        if os.path.exists('results/documents_scored.npz'):
            documents = np.load('results/documents_scored.npz', allow_pickle=True)['arr_0'][()]
            for document in documents:
                self.docId_to_doc[document.docId] = document
            print('Documents Loaded.')
        else:
            print('Documents not found.')

    def spelling_correction(self, query):
        pass

    def query_processe(self, query):
        query_terms = []
        ps = PorterStemmer()
        tokens = word_tokenize(query)

        for token in tokens:
            if token.isalnum():
                query_terms.append(ps.stem(token))

        return query_terms

    def load_term_postings(self, terms):
        term_postings_dict = {}
        query_terms = []
        for term in terms:
            postings = self.get_posting_list(term)
            if postings is not None:
                term_postings_dict[term] = postings
                query_terms.append(term)
        return term_postings_dict, query_terms

    def convert_term_postings_to_incidence_matrix(self, term_postings_dict, query_terms):
        docId_set = set()
        for term, postings in term_postings_dict.items():
            for posting in postings:
                docId_set.add(posting.docId)
        docId_to_i = {}
        term_to_i = {}
        i_to_docId = {}
        for i, term in enumerate(query_terms):
            term_to_i[term] = i
        if len(docId_set) == 0:
            return None
        else:
            for i, docId in enumerate(docId_set):
                docId_to_i[docId] = i
                i_to_docId[i] = docId
            incidence_matrix = np.zeros((len(docId_set), len(query_terms)))

            for term, postings in term_postings_dict.items():
                for posting in postings:
                    incidence_matrix[docId_to_i[posting.docId], term_to_i[term]] = posting.tf_idf
        return incidence_matrix, docId_to_i, term_to_i, i_to_docId

    def free_text_search(self, query):
        query_terms = self.query_processe(query)
        term_postings_dict, query_terms = self.load_term_postings(query_terms)
        documents = []

        if len(query_terms) == 1:
            sorted_postings = sorted(term_postings_dict[query_terms[0]], key=lambda x: self.docId_to_doc[x.docId].pagerank, reverse=True)
            print(f'Top 5 results for {query}:')
            for posting in sorted_postings[:5]:
                print(self.docId_to_doc[posting.docId].url)
                documents.append(self.docId_to_doc[posting.docId])
        else:
            incidence_matrix, docId_to_i, term_to_i, i_to_docId = self.convert_term_postings_to_incidence_matrix(term_postings_dict, query_terms)

            # calculate cosine sim
            v = np.zeros_like(range(len(query_terms)), dtype=np.float32)
            for term in query_terms:
                length = len(term_postings_dict[term])
                idf = math.log10(len(self.docId_to_doc) / length)
                v[term_to_i[term]] = idf
            A_B = np.dot(incidence_matrix, v)
            A_ = norm(incidence_matrix, axis=1)
            B_ = norm(v)
            cosine = A_B/(A_*B_)
            inds = np.argsort(np.squeeze(cosine))[-1:-6:-1]
            print(f'Top 5 results for {query}:')
            
            for ind in inds:
                print(self.docId_to_doc[i_to_docId[ind]].url)
                documents.append(self.docId_to_doc[i_to_docId[ind]])

        return self.results(documents)

    def intersect(self, s1, s2):
        if len(s1) == 0 or len(s2) == 0:
            return None
        o = []
        i = j = 0
        m = min(s1[-1], s2[-1])
        while s1[i] < m and s2[j] < m:
            if s1[i] == s2[j]:
                o.append(s1[i])
                i += 1
                j += 1
            elif s1[i] < s2[j]:
                i += 1 
            else: 
                j += 1
        if (s1[-1] == s2[j] == m) or (s2[-1] == s1[i] == m):
            o.append(m)
        return o

    def boolean_retrieval(self, query):
        query_terms = self.query_processe(query)
        term_postings_dict, query_terms = self.load_term_postings(query_terms)
        
        min_length_postings = min(term_postings_dict.values(), key=lambda x: len(x))
        docId_intersection = [posting.docId for posting in min_length_postings]

        for term, postings in term_postings_dict.items():
            docId_list = [posting.docId for posting in postings]
            docId_list = sorted(docId_list)
            docId_intersection = self.intersect(docId_intersection, docId_list)
            if docId_intersection is None:
                return None
        
        return self.results([self.docId_to_doc[docId] for docId in docId_intersection])

    def results(self, documents):
        results = []
        for document in documents:
            with open(document.file_path, 'r') as f:
                content = json.load(f)['content']
                soup = BeautifulSoup(content, 'html.parser')
                description = soup.get_text()[:100]
                title_tag = soup.find('title')
                if title_tag is not None:
                    title = title_tag.get_text()
                    if len(title) > 50:
                        title = title[:50]
                else:
                    title = description[:10]
            results.append((document.url, title, description))
        return results

    def phrase_search(self, query):
        pass

    def get_posting_list(self, term):
        """Read the term from the index and return the posting list."""
        postings_list = []
        if term in self.inverted_indexes:
            idf = math.log10(len(self.docId_to_doc) / len(self.inverted_indexes[term]))
            if idf < 0.5:
                return None
            return self.inverted_indexes[term]
        elif term[0] not in self.indexes:
            filename = 'index_files/others.json'
        elif term[1] in self.indexes and term[2] in self.indexes:
            filename = f'index_files/{term[0]}{term[1]}{term[2]}.npz'
        else:
            filename = f'index_files/{term[0]}-others.npz'
        try:
            postings = np.load(filename, allow_pickle=True)['arr_0'][()][term]
            idf = math.log10(len(self.docId_to_doc) / len(postings))
            if idf < 0.5:
                return None
            for posting in postings:
                if self.docId_to_doc[posting.docId].pagerank > 0.1 / len(postings):
                    postings_list.append(posting)
        except:
            print('The term doesn\'t exist.')
            return None
        if len(postings_list) == 0:
            return None
        return postings_list