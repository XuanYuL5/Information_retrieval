import json
import nltk
nltk.download('punkt')
from tqdm import tqdm
from glob import glob
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize


#codes from:  https://medium.com/@fro_g/writing-a-simple-inverted-index-in-python-3c8bcb52169a
class Posting:
    """
    Represents the Posting of a term in a given document, along with the frequency of appearances in the same one.
    """
    def __init__(self, docId, frequency):
        self.docId = docId
        self.frequency = frequency
        
    def __repr__(self):
        """
        String representation of the Posting object
        """
        return str(self.__dict__)

#Ideas from: https://docs.python.org/3/library/json.html
class PostingEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Posting):
            return eval(str(obj))
        else:
            return super(PostingEncoder, self).default(obj)

#Codes from: https://medium.com/@fro_g/writing-a-simple-inverted-index-in-python-3c8bcb52169a#:~:text=What%20is%20an%20Inverted%20Index,the%20term%20in%20the%20document.
class InvertedIndex:
    """
    Inverted Index class.
    """
    def __init__(self):
        self.index = dict()
        self.ps = PorterStemmer()
        self.index_file_num = 0

    def __repr__(self):
        """
        String representation of the Database object
        """
        return str(self.index)

    # Some of the code for this function references the content in this web page https://medium.com/@fro_g/writing-a-simple-inverted-index-in-python-3c8bcb52169a#:~:text=What%20is%20an%20Inverted%20Index,the%20term%20in%20the%20document. 
    def index_document(self, document):
        """
        Process a given document, save it to the DB and update the index.
        """
        
        # Remove punctuation from the text.
        terms = []
        punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '&', '!', '*', '@', '#', '$', '%', '<', '>','--','=','/','|','’','‘','{','}','`','\\','\'','-','_','+','\\\\','\\\\\\','~']

        for p in punctuations:
            document['content'] = document['content'].replace(p, ' ')

        words = word_tokenize(document['content'])
        for w in words:
            if w.isdigit() or len(w) > 20:
                continue
            terms.append(self.ps.stem(w))
        postings_dict = dict()
        last_tag = None
        important_tags = ['b', 'strong', 'h1', 'h2', 'h3', 'title']
        
        # Dictionary with each term and the frequency it appears in the text.
        #Ideas from: https://medium.com/@fro_g/writing-a-simple-inverted-index-in-python-3c8bcb52169a#:~:text=What%20is%20an%20Inverted%20Index,the%20term%20in%20the%20document.
        for term in terms:
            term_frequency = postings_dict[term].frequency if term in postings_dict else 0
            if last_tag is None and term in important_tags:
                last_tag = term
                postings_dict[term] = Posting(document['url'], term_frequency + 1)
            elif last_tag is None and term not in important_tags:
               postings_dict[term] = Posting(document['url'], term_frequency + 1)
            elif last_tag is not None and term == last_tag:
                postings_dict[term] = Posting(document['url'], term_frequency + 1)
                last_tag = None
            else:
                postings_dict[term] = Posting(document['url'], term_frequency + 10)
            
        # Update the inverted index
        update_dict = { key: [posting]
                       if key not in self.index
                       else self.index[key] + [posting]
                       for (key, posting) in postings_dict.items() }
        self.index.update(update_dict)
    
    def construct_index(self, documents_path):
        """
        Construct the inverted index.
        """
        count = 0
        for document_path in tqdm(documents_path):
            count += 1
            with open(document_path, 'r') as f:
                document = json.load(f)
                self.index_document(document)
                if len(self.index) > 4000:
                    self.save_index_file(self.index, f'index_files/{self.index_file_num}.json')
                    self.index_file_num += 1
                    self.index = dict()
        self.save_index_file(self.index, f'index_files/{self.index_file_num}.json')
        self.index_file_num += 1
        self.index = dict()

    #Ideas from: https://stackoverflow.com/questions/12309269/how-do-i-write-json-data-to-a-file
    def save_index_file(self, index, file_name):
        """
        Save the index to a file.
        """
        json_str = json.dumps(index, indent=4, cls=PostingEncoder)
        with open(file_name, 'w') as f:
            f.write(json_str)
    
    #Codes from: https://stackoverflow.com/questions/12309269/how-do-i-write-json-data-to-a-file
    def merge_index_files(self):
        """
        Merge all the index files into indexed files.
        """
        indexes = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        unique_token_count = 0
        index_merged = dict()
        for index in tqdm(indexes):
            for i in range(self.index_file_num):
                with open(f'index_files/{i}.json', 'r') as f:
                    data = json.load(f)
                    for key, value in data.items():
                        if key[0] == index:
                            if key not in index_merged:
                                index_merged[key] = value
                            else:
                                index_merged[key] += value
            unique_token_count += len(index_merged)
            self.save_index_file(index_merged, f'index_files/{index}.json')
            index_merged = dict()
        
        for i in range(self.index_file_num):
            with open(f'index_files/{i}.json', 'r') as f:
                data = json.load(f)
                for key, value in data.items():
                    if key[0] not in indexes:
                        if key not in index_merged:
                            index_merged[key] = value
                        else:
                            index_merged[key] += value
        unique_token_count += len(index_merged)
        self.save_index_file(index_merged, 'index_files/others.json')
        index_merged = dict()
        print('Number of Unique Tokens:', unique_token_count)


index = InvertedIndex()
files_path = glob('DEV/*/*.json')
print(len(files_path))
index.construct_index(files_path)
index.merge_index_files()